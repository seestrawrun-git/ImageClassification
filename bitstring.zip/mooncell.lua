require "bitstring"
require "json"

-------------------
-- UDP socket --
-------------------
-- Create socket
local socket = require("socket")
local udp = socket.udp()
-- On data received
udp.Data = function(udp, packet) 
  print (packet.Address)
  if packet.Address == '10.10.10.220' then
    data = packet.Data
    parseData(data)
    Controls.lastPacket.String = bitstring.hexstream(data) -- populate text display 
    --udp:Send("10.10.10.249", 20002, packet.Data) -- relay message to touch designer on new port 
    print (bitstring.hexstream(data))
  end   
end
udp:Open("",20001) -- open UDP listner 

-- define touch zones by xy.  
zones = {
  function (x, y) return (x > 0 and x <= 192) and (y > 0 and y <= 192) end, -- 1,1 
  function (x, y) return (x > 384 and x <= 576) and (y > 0 and y <= 192) end, -- 1,3 
  function (x, y) return (x > 768 and x <= 960) and (y > 0 and y <= 192) end, -- 1,5 
  function (x, y) return (x > 1152 and x <= 1344) and (y > 0 and y <= 192) end, -- 1,7 
  function (x, y) return (x > 1536 and x <= 1728) and (y > 0 and y <= 192) end, -- 1,9 
  
  function (x, y) return (x > 192 and x <= 384) and (y > 192 and y <= 384) end, -- 2,2 
  function (x, y) return (x > 576 and x <= 768) and (y > 192 and y <= 384) end, -- 2,4 
  function (x, y) return (x > 960 and x <= 1152) and (y > 192 and y <= 384) end, -- 2,6
  function (x, y) return (x > 1344 and x <= 1536) and (y > 192 and y <= 384) end, -- 2,8 
  function (x, y) return (x > 1728 and x <= 1920) and (y > 192 and y <= 384) end, -- 2,10 

  function (x, y) return (x > 0 and x <= 192) and (y > 384 and y <= 576) end, -- 3,1 
  function (x, y) return (x > 384 and x <= 576) and (y > 384 and y <= 576) end, -- 3,3 
  function (x, y) return (x > 768 and x <= 960) and (y > 384 and y <= 576) end, -- 3,5 
  function (x, y) return (x > 1152 and x <= 1344) and (y > 384 and y <= 576) end, -- 3,7 
  function (x, y) return (x > 1536 and x <= 1728) and (y > 384 and y <= 576) end, -- 3,9 

  function (x, y) return (x > 192 and x <= 384) and (y > 576 and y <= 768) end, -- 4,2 
  function (x, y) return (x > 576 and x <= 768) and (y > 576 and y <= 768) end, -- 4,4 
  function (x, y) return (x > 960 and x <= 1152) and (y > 576 and y <= 768) end, -- 4,6
  function (x, y) return (x > 1344 and x <= 1536) and (y > 576 and y <= 768) end, -- 4,8 
  function (x, y) return (x > 1728 and x <= 1920) and (y > 576 and y <= 768) end, -- 4,10

  function (x, y) return (x > 0 and x <= 192) and (y > 768 and y <= 960) end, -- 5,1 
  function (x, y) return (x > 384 and x <= 576) and (y > 768 and y <= 960) end, -- 5,3 
  function (x, y) return (x > 768 and x <= 960) and (y > 768 and y <= 960) end, -- 5,5 
  function (x, y) return (x > 1152 and x <= 1344) and (y > 768 and y <= 960) end, -- 5,7 
  function (x, y) return (x > 1536 and x <= 1728) and (y > 768 and y <= 960) end, -- 5,9 

  function (x, y) return (x > 192 and x <= 384) and (y > 960 and y <= 1152) end, -- 6,2 
  function (x, y) return (x > 576 and x <= 768) and (y > 960 and y <= 1152) end, -- 6,4 
  function (x, y) return (x > 960 and x <= 1152) and (y > 960 and y <= 1152) end, -- 6,6
  function (x, y) return (x > 1344 and x <= 1536) and (y > 960 and y <= 1152) end, -- 6,8 
  function (x, y) return (x > 1728 and x <= 1920) and (y > 960 and y <= 1152) end, -- 6,10

  function (x, y) return (x > 0 and x <= 192) and (y > 1152 and y <= 1344) end, -- 7,1 
  function (x, y) return (x > 384 and x <= 576) and (y > 1152 and y <= 1344) end, -- 7,3 
  function (x, y) return (x > 768 and x <= 960) and (y > 1152 and y <= 1344) end, -- 7,5 
  function (x, y) return (x > 1152 and x <= 1344) and (y > 1152 and y <= 1344) end, -- 7,7 
  function (x, y) return (x > 1536 and x <= 1728) and (y > 1152 and y <= 1344) end, -- 7,9 

  function (x, y) return (x > 192 and x <= 384) and (y > 1344 and y <= 1536) end, -- 8,2 
  function (x, y) return (x > 576 and x <= 768) and (y > 1344 and y <= 1536) end, -- 8,4 
  function (x, y) return (x > 960 and x <= 1152) and (y > 1344 and y <= 1536) end, -- 8,6
  function (x, y) return (x > 1344 and x <= 1536) and (y > 1344 and y <= 1536) end, -- 8,8 
  function (x, y) return (x > 1728 and x <= 1920) and (y > 1344 and y <= 1536) end, -- 8,10

  function (x, y) return (x > 0 and x <= 192) and (y > 1536 and y <= 1728) end, -- 9,1 
  function (x, y) return (x > 384 and x <= 576) and (y > 1536 and y <= 1728) end, -- 9,3 
  function (x, y) return (x > 768 and x <= 960) and (y > 1536 and y <= 1728) end, -- 9,5 
  function (x, y) return (x > 1152 and x <= 1344) and (y > 1536 and y <= 1728) end, -- 9,7 
  function (x, y) return (x > 1536 and x <= 1728) and (y > 1536 and y <= 1728) end, -- 9,9 

  function (x, y) return (x > 192 and x <= 384) and (y > 1728 and y <= 1920) end, -- 10,2 
  function (x, y) return (x > 576 and x <= 768) and (y > 1728 and y <= 1920) end, -- 10,4 
  function (x, y) return (x > 960 and x <= 1152) and (y > 1728 and y <= 1920) end, -- 10,6
  function (x, y) return (x > 1344 and x <= 1536) and (y > 1728 and y <= 1920) end, -- 10,8 
  function (x, y) return (x > 1728 and x <= 1920) and (y > 1728 and y <= 1920) end, -- 10,10
} 

goodPackets = 0 
badPackets = 0 

function updateLEDs (x,y)
  for i, v in ipairs (zones) do -- for each zone condition 
    if zones[i](x,y) then -- if xy is within zone 
      Controls.touchZones[i].Boolean = true -- set LED true 
      Timer.CallAfter(function() -- clear LED 
        Controls.touchZones[i].Boolean = false 
      end, 1)  
    end    
  end 
end 

parseData = function (data)
  if goodPackets == 1024 then goodPackets = 0 end -- reset counters 
  if badPackets == 1024 then badPackets = 0 end -- reset counters 

  local touchArray = {} -- overwrite with active touch data each packet 

  local startChars = bitstring.hexstream(data,1,3) -- extract first 3 bytes, should always be 555500
  if startChars == '555500' then -- check packet 
    goodPackets = goodPackets + 1 -- counter for valid packets 

    local highByte = bitstring.hexstream(data,4,4) -- high byte for packet length (used to determine number of touch points in packet)
    local lowByte = bitstring.hexstream(data,5,5) -- low byte for packet length (used to determine number of touch points in packet)
    local numTouches = (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) / 4 -- calculate number of touches
    --print ('Number of Touches:', (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) / 4 ) 
    Controls.numTouches.String = numTouches

    if numTouches <= 30 then -- number of simultaneous touches allowd 
      for i = 1, numTouches do -- for each touch extract co-ordinates 
        touchArray[i] = {
        ['X'] = getX (data, i), -- populate active touch array 
        ['Y'] = getY (data, i),} -- populate active touch array 
      end 
    end 
    --print (json.encode(touchArray))
    Controls.activeTouches.String = json.encode(touchArray) -- populate text display 
  else badPackets = badPackets + 1 -- counter for invalid packets 
  end   

  Controls.goodPackets.String = goodPackets -- populate text display 
  Controls.badPackets.String = badPackets -- populate text display 

  for i, touch in ipairs (touchArray) do 
    updateLEDs(touch.X, touch.Y)
  end 

end 

getX = function (data, inputNum)
  -- calculate postion of bytes in string 
  local highByteLoc = 6 + (inputNum - 1) * 4 -- 6 (start byte) + index - 1 * 4 (number of bytes between start bytes)
  local lowByteLoc = 6 + (inputNum - 1) * 4 + 1 -- 6 (start byte) + index - 1 * 4 (number of bytes between start bytes) + 1 (end byte for co-ordinate)
  -- extract data 
  local highByte = bitstring.hexstream(data,highByteLoc,highByteLoc)
  local lowByte = bitstring.hexstream(data,lowByteLoc,lowByteLoc)
  --print ('X Value:', inputNum, (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) ) 
  return (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) -- return result of X co-ordinate 
end 

getY = function (data, inputNum)
  -- calculate postion of bytes in string 
  local highByteLoc = 8 + (inputNum - 1) * 4 -- 6 (start byte) + index - 1 * 4 (number of bytes between start bytes)
  local lowByteLoc = 8 + (inputNum - 1) * 4 + 1 -- 6 (start byte) + index - 1 * 4 (number of bytes between start bytes) + 1 (end byte for co-ordinate)
  -- extract data
  local highByte = bitstring.hexstream(data,highByteLoc,highByteLoc)
  local lowByte = bitstring.hexstream(data,lowByteLoc,lowByteLoc)
  --print ('Y Value:', inputNum, (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) ) 
  return (tonumber(highByte, 16) * 256) + tonumber(lowByte, 16) -- return result of Y co-ordinate
end 
